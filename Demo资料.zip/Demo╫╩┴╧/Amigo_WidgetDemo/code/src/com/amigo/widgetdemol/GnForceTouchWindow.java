package com.amigo.widgetdemol;

import amigoui.app.AmigoActivity;
import amigoui.forcetouch.AmigoForceTouchClickCallback;
import amigoui.forcetouch.AmigoForceTouchControl;
import amigoui.forcetouch.AmigoForceTouchMenuCallback;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class GnForceTouchWindow extends AmigoActivity implements AmigoForceTouchClickCallback {

    private final static String LOGTAG = "GnForceTouchWindow";
    private TextView mForceView;
    private AmigoForceTouchControl mForceCtrl;
    AmigoForceTouchMenuCallback mCreater;
    private Button mBtn1;
    private Button mBtn2;
    private Button mBtn3;
    private Button mBtn4;
    private Button mBtn5;
    private Button mBtn6;
    private ImageView mImgView;
    
    private void startHidePopMenuAnimations(final View view) {
        Log.e(LOGTAG, "startHidePopMenuAnimations start");
        final ScaleAnimation anim = new ScaleAnimation(1.0f, 0.0f, 1.0f, 0.0f,
                Animation.ABSOLUTE, 400.0f, Animation.ABSOLUTE, 400.0f);
        anim.setDuration(500);
        mImgView.setAnimation(anim);
        anim.startNow();
        mImgView.setVisibility(View.INVISIBLE);
        anim.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }
        });
    }
    
    Handler mHandler = new Handler() {
        
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gn_force_touch_demo);
//        mForceView = (TextView) findViewById(R.id.forceTxt);
        mBtn1 = (Button) findViewById(R.id.button1);
        mBtn2 = (Button) findViewById(R.id.button2);
        mBtn3 = (Button) findViewById(R.id.button3);
        mBtn4 = (Button) findViewById(R.id.button4);
        mBtn5 = (Button) findViewById(R.id.button5);
        mBtn6 = (Button) findViewById(R.id.button6);
        mImgView = (ImageView) findViewById(R.id.button7);
        
        mBtn2.setOnLongClickListener(new View.OnLongClickListener() {
            
            @Override
            public boolean onLongClick(final View v) {
                Toast.makeText(GnForceTouchWindow.this, "onLongClick", Toast.LENGTH_SHORT).show();
                startHidePopMenuAnimations(v);
                mBtn5.setScaleX(1.5f);
                mBtn5.setScaleY(1.5f);
                
                return false;
            }
        });
        mBtn2.setOnClickListener(new View.OnClickListener() {
            
            @Override
            public void onClick(View v) {
                ObjectAnimator obj = ObjectAnimator.ofFloat(mBtn5, "scaleX", 1f, 0.2f);
                obj.setDuration(1000);
                obj.start();
            }
        });
        mForceCtrl = new AmigoForceTouchControl(this);
        initForceTouchMenu();
        mForceCtrl.setAmigoForceTouchMenuCallback(mCreater);
        mForceCtrl.setAmigoForceTouchClickCallback(this);
        
        mForceCtrl.registerForceTouchView(mBtn1);
        mForceCtrl.registerForceTouchView(mBtn2);
        mForceCtrl.registerForceTouchView(mBtn3);
        mForceCtrl.registerForceTouchView(mBtn4);
        mForceCtrl.registerForceTouchView(mBtn5);
        mForceCtrl.registerForceTouchView(mBtn6);
        mForceCtrl.registerForceTouchView(mImgView);
    }

    void initForceTouchMenu() {
        mCreater = new AmigoForceTouchMenuCallback() {

            @Override
            public void onCreateForceTouchMenu(View view, Menu menu) {
                
                getMenuInflater().inflate(R.menu.gn_actionmenu_demo, menu);
            }

            @Override
            public void onPrepareForceTouchMenu(View view, Menu menu) {
                int id = view.getId();
                switch(id) {
                case R.id.button2:
                    menu.getItem(1).setEnabled(false);
                    break;
                default:
                    break;
                }
            }

            @Override
            public void onForceTouchMenuItemClick(View view,
                    MenuItem menuItem) {
                Log.e(LOGTAG,"onForceTouchMenuItemClick item="+menuItem.getItemId()+";text="+menuItem.getTitle());
            }
        };
    }

    @Override
    public boolean onLightTouchClick(View view, float pressure) {
        return false;
    }

    @Override
    public boolean onForceTouchClick(View view) {
        return false;
    }

    @Override
    public void onForceTouchClickView(View view) {
        Log.e(LOGTAG,"onTouchClick view");
    }
}
