package com.amigo.widgetdemol;

import amigoui.app.AmigoActivity;
import android.os.Bundle;

public class GnSwitchButtonWindow extends AmigoActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gn_switch_window);
    }
}
