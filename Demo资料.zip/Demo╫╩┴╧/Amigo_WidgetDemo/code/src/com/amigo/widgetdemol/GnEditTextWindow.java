package com.amigo.widgetdemol;

import amigoui.app.AmigoActivity;
import android.os.Bundle;

public class GnEditTextWindow extends AmigoActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gn_edit_text_window);
    }
}
