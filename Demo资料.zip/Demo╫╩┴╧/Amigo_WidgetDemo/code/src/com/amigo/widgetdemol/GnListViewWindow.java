package com.amigo.widgetdemol;

import java.util.ArrayList;
import java.util.List;

import amigoui.app.AmigoListActivity;
import amigoui.widget.AmigoListDismissAnimation;
import amigoui.widget.AmigoListView;
import amigoui.widget.OnAmigoItemDismissCallback;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;

public class GnListViewWindow extends AmigoListActivity {
    private List<Integer> mSelectedPositions;
    private List<String> mDatas;
    private BaseAdapter mAdapter;
    /**
     * Step1: {@link AmigoListDismissAnimation} Object.
     */
    private AmigoListDismissAnimation mAnimateDismiss;
    
    private String[] mMovieStrings = {
            "星球大战系列",
            "异次元骇客（第十三层）",
            "超人",
            "终结者（1、2）",
            "12猴子",
            "黑客帝国系列",
            "移魂都市（黑暗城市）",
            "超时空接触",
            "千钧一发",
            "2001漫游太空",
            "肖申克的救赎",
            "教父",
            "美国往事",
            "天堂电影院",
            "无主之城",
            "活着",
            "阿甘正传",
            "勇敢的心",
            "楚门的世界",
            "音乐之声",
            "辛德勒的名单",
            "拯救大兵瑞恩",
            "猎杀红色十月",
            "兵临城下",
            "大逃杀",
            "巴顿将军",
            "u-571",
            "全金属外壳",
            "星际舰队",
            "瓦尔特保卫萨拉热窝",
            "野战排",
            "英雄本色",
            "真实的谎言",
            "生死时速",
            "虎胆龙威系列",
            "勇闯夺命岛",
            "刀锋战士",
            "神秘的黄玫瑰系列",
            "复仇",
            "三步杀人曲系列",
            "第一滴血"
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDatas = getDummyItems();
        mSelectedPositions = new ArrayList<Integer>();
        mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mAdapter = new MyListAdapter();
        /**
         * Step2: New AmigoListDismissAnimation instance, the parameter is your current ListView instance.
         */
        mAnimateDismiss = new AmigoListDismissAnimation(getListView());
        /**
         * Step3: Set callback for AmigoListDismissAnimation.
         */
        mAnimateDismiss.setAmigoItemDismissCallback(new MyOnDismissCallback());
        
        setListAdapter(mAdapter);
    }
    
    @Override
    protected void onListItemClick(AmigoListView l, View v, int position, long id) {
        CheckedTextView tv = ((CheckedTextView) v.findViewById(R.id.checktext));
        tv.toggle();
        if (tv.isChecked()) {
            mSelectedPositions.add(position);
        } else {
            mSelectedPositions.remove((Integer) position);
        }
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gn_listview_animation_delete_demo, menu);
        return super.onCreateOptionsMenu(menu);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        /**
         * Step4: start Animation, notice that you must pass a collect of positions your wanted to delete.
         * This method is called at the time between delete had started and will start refresh ListView.  
         */
        mAnimateDismiss.startAnimation(mSelectedPositions);
        mSelectedPositions.clear();
        return super.onOptionsItemSelected(item);
    }
    
    private ArrayList<String> getDummyItems() {
        ArrayList<String> items = new ArrayList<String>();
        for (int i = 0; i < mMovieStrings.length; i++) {
            items.add(mMovieStrings[i]);
        }
        return items;
    }
    private LayoutInflater mInflater;
    private class MyListAdapter extends BaseAdapter {

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CheckedTextView tv;
            if (convertView == null) {
                convertView = (View)mInflater.inflate(
                        R.layout.gn_animateremoval_row, parent, false);
                tv = (CheckedTextView)convertView.findViewById(R.id.checktext);
                convertView.setTag(tv);
            } else {
                tv = (CheckedTextView)convertView.getTag();
            }
            tv.setText(mDatas.get(position));
            tv.setChecked(mSelectedPositions.contains(position));
            return convertView;
        }

        @Override
        public int getCount() {
            return mDatas.size();
        }

        @Override
        public Object getItem(int position) {
            return mDatas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
    }
    /**
     * Step5: when animation is over, you can update your ListView in this callback.
     * 
     */
    private class MyOnDismissCallback implements OnAmigoItemDismissCallback {

        @Override
        public void onDismiss(AbsListView listView, int[] reverseSortedPositions) {
            for (int position : reverseSortedPositions) {
                mDatas.remove(position);
                mAdapter.notifyDataSetChanged();
            }
        }
    }
}
