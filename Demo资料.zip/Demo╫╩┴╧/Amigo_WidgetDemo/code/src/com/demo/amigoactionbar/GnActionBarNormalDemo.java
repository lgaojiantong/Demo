package com.demo.amigoactionbar;

import amigoui.app.AmigoActivity;
import android.os.Bundle;

import com.amigo.widgetdemol.R;

public class GnActionBarNormalDemo extends AmigoActivity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gn_actionbar_normal_demo);
		//AmigoActionBar actionBar = getAmigoActionBar();
		//actionBar.setDisplayShowExtraViewEnabled(true);
	}
}
