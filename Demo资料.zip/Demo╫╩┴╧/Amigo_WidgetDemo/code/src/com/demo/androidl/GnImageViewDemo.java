package com.demo.androidl;

import android.app.Activity;
import android.os.Bundle;

import com.amigo.widgetdemol.R;

public class GnImageViewDemo extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gn_image_view_demo);
    }
}
