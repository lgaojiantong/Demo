package com.demo.androidl;

import android.app.Activity;
import android.os.Bundle;

import com.amigo.widgetdemol.R;

public class GnShadowDemo extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gn_shadow_demo);
    }
}
