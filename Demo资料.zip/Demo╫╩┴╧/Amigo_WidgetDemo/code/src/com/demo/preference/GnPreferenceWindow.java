package com.demo.preference;

import java.lang.reflect.Method;

import amigoui.preference.AmigoCheckBoxAndClickPreference;
import amigoui.preference.AmigoEditTextPreference;
import amigoui.preference.AmigoPreference;
import amigoui.preference.AmigoPreferenceActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.amigo.widgetdemol.R;

public class GnPreferenceWindow extends AmigoPreferenceActivity {

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        addPreferencesFromResource(R.xml.gionee_preference);

        AmigoPreference amigoVersion = (AmigoPreference) findPreference("pref_key_version");        
        String version = getAmigoFrameworkVersion();
        amigoVersion.setSummary(version);        
        AmigoCheckBoxAndClickPreference checkAndClickPreference =(AmigoCheckBoxAndClickPreference) findPreference("pref_key_check_click");
        checkAndClickPreference.setRBtnOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GnPreferenceWindow.this, "点击显示", Toast.LENGTH_SHORT).show();
            }
        });
        AmigoEditTextPreference editPreference = (AmigoEditTextPreference) findPreference("testEditPreference");
        editPreference.setDialogMessage("SIM卡PIN码");
        
    }
    
    private String getAmigoFrameworkVersion() {
        String version = "";
        Class<?> verClass = null;
        
        try{
            verClass = Class.forName("amigo.widget.AmigoWidgetVersion");
        }catch (Exception e){
            e.printStackTrace();
        }
        
        try {
            Method method = verClass.getMethod("getVersion");
            version = (String)method.invoke(this);
        }catch (Exception e) {
            e.printStackTrace();
        }
        
        return version;
    }
    
    
}
