package com.demo.amigolistitem;

public class ItemData {
    public int mHeadIcon;
    public int mTailIcon;
    public String mFirstSummary;
    public String mSecondSummary;
    public String mThirdSummary;
    public String mSecondAfterSummary;
    public int mType;
}
