package com.demo.amigoseekbar;

import com.amigo.widgetdemol.R;

import amigoui.app.AmigoActivity;
import android.os.Bundle;

public class GnSeekbarActivity extends AmigoActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gn_seekbar_layout);
    }

}
